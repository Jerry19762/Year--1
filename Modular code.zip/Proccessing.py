def calculating_numbers(num1, num2):
    results = {}
    results["sum"]= num1 + num2
    results["difference"]= num1 - num2
    results["product"]= num1 * num2
    results["quotient"]= num1 / num2 if num2 != 0 else ("error (division by zero)")
    return results
    
    
