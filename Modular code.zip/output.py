def results_display(num1, num2, results):
    outputs = []
    for operation, result in results.items():
        if operation == "quotient" and results == "error (division by zero)":
            output=f"The {operation} of {num1} and {num2} is error (division by zero)"
        else:
            ouput=f"The {operation} of {num1} and {num2} is {result}"
        print(output)
        outputs.append(output)
    save_to_file(outputs)

def save_to_file(outputs):
    with open("calculation.txt", "a") as file:
        for output in outputs:
            file.write(output + "\n")
    
        
