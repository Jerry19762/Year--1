def getting_numbers():
    try:
        num1 = float(input("input the first number"))
        num2 = float(input("input the second number"))
        return num1,num2
    except error:
        print("Error! Please input numbers")
        return getting_numbers()
