from Modules.Input import getting_numbers
from Modules.Proccessing import calculating_numbers
from Modules.output import results_display

def main():
    print("Welcome to the calculator")
    while True:
        num1, num2 = getting_numbers
        results = calculating_numbers(num1, num2)
        results_display(num1, num2, results)
        choice + input("do you want to perform another calculation? (yes/no):").strip().lower()
        if choice != "yes":
            print("Bye")
            break
if __name__== "__main__":
    main()
        
